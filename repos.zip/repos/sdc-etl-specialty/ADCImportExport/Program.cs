﻿//Microsoft sample

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;
using System.Net;
using System.Data;
using Newtonsoft.Json; //Install-Package Newtonsoft.Json
using Newtonsoft.Json.Linq;
using Microsoft.IdentityModel.Clients.ActiveDirectory; //Install-Package Microsoft.IdentityModel.Clients.ActiveDirectory

namespace ADCImportExport
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                System.Console.WriteLine("export file_path [-search search_string]");

                Console.ReadLine();
                return;
            }

            string operation = args[0];
            string filePath = args[1];

            AzureDataCatalog td = new AzureDataCatalog();

            if (operation.Equals("-export"))
            {
                string searchString = "";

                if ((args.Length >= 4) && (args[2].ToLower().Equals("-search")))
                {
                    searchString = args[3];
                }

                using (StreamWriter sw = new StreamWriter(filePath, false))
                {
                    int count = Export(td, sw, searchString);
                    System.Console.WriteLine("Items Exported: " + count);
                }               

            }
            /* else if (operation.Equals("-import"))
            {
                Import(td, filePath); //Import functionality is possible but not implemented
            } */
            else
            {
                System.Console.WriteLine("Must specify either import or export"); //Think what to do here

            }
            Console.ReadLine();
        }

        static int Export(AzureDataCatalog td, StreamWriter sw, string searchString) //Describe the funtion
        {
            const int countPerPage = 100;

            bool firstTime = true;
            int startPage = 1;
            int totalResultsCount = 0;
            int totalExportedSuccessfully = 0;
            int col_desc_cnt = 0;
            int col_cnt = 0;
            int coltag_cnt = 0;
            int desc_cnt = 0;
            int tags_cnt = 0;       

            sw.Write("{\"catalog\":["); //Use exception handling and show the corresponding message
            do
            {
                string results = td.Search(searchString, startPage, countPerPage);

                if (results == null)
                {
                    return 0;
                }

                if (firstTime)
                {
                    totalResultsCount = (int)JObject.Parse(results)["totalResults"];
                }
                var assetList = JObject.Parse(results)["results"].Children();//explain what's being referenced
                int assetListcnt = JObject.Parse(results)["results"].Children().Count();

                //Building the Column CSV
                var col_csv = new StringBuilder();
                var TableName = "TableName";
                var ColumnName = "ColumnName";
                var Description = "Description";
                var ColTags = "ColumnTags";
                var type = "Type";
                var MaxLength = "MaxLength";
                var Precision = "Precision";
                var IsNullable = "IsNullable";
                var col_header = string.Format("{0},{1},{2},{3},{4},{5},{6},{7}", TableName, ColumnName, Description, ColTags, type, MaxLength, Precision, IsNullable);
                col_csv.AppendLine(col_header);

                //Building the Table CSV
                var tbl_csv = new StringBuilder();
                var Name = "TableName";
                var FriendlyName = "FriendlyName";
                var TableDescription = "Description";
                var TableTags = "TableTags";
                var nameoflastregisteredby = "Last_Registered_By";
                var emailoflastregisteredby = "Email";
                var documentation = "Documentation";
                var tbl_header = string.Format("{0},{1},{2},{3},{4},{5},{6}", Name, FriendlyName, TableDescription, TableTags, nameoflastregisteredby, emailoflastregisteredby, documentation);
                tbl_csv.AppendLine(tbl_header);

                foreach (JObject asset in assetList["content"])
                {

                    if ((asset["properties"]["dataSource"]["objectType"].ToString()).Equals("Table"))
                    {
                        if (firstTime)
                        {
                            firstTime = false;
                        }
                        else
                        {
                            sw.Write(",");
                        }

                        if (asset["annotations"]["columnDescriptions"] != null)
                        {
                            col_desc_cnt = asset["annotations"]["columnDescriptions"].Children().Count();
                        }
                        if (asset["annotations"]["schema"]["properties"]["columns"] != null)
                        {
                            col_cnt = asset["annotations"]["schema"]["properties"]["columns"].Children().Count();
                        }
                        if (asset["annotations"]["columnTags"] != null)
                        {
                            coltag_cnt = asset["annotations"]["columnTags"].Children().Count();
                        }
                        if (asset["annotations"]["descriptions"] != null)
                        {
                            desc_cnt = asset["annotations"]["descriptions"].Children().Count();
                        }
                        if (asset["annotations"]["tags"] != null)
                        {
                            tags_cnt = asset["annotations"]["tags"].Children().Count();
                        }

                        // (asset["properties"] as JObject).Remove("containerId");
                        // (asset["properties"] as JObject).Remove("dsl");

                        /*
                         *(EXAMPLE) dsl{3} contains the following:
                             * address{4}:
                                server name: coapocdbserver2.database.windows.net
                                database name: coapoc_db
                                schema name: QNXT
                                object name: SPECIALTY_MV
                            * protocol: tds
                            * authentication: protocol
                        */
                        // (asset["properties"] as JObject).Remove("dataSource");

                        /*
                         *(EXAMPLE) dataSource{2} contains the following:
                            * sourceType: SQL Server
                            * objectType: Table
                        */

                        // (asset["properties"] as JObject).Remove("lastRegisteredBy");
                        //the above line is commented, as we might require "lastRegisteredBy"
                        // (asset["properties"] as JObject).Remove("fromSourceSystem");

                        var annotationsNode = asset.SelectToken("annotations") as JObject;

                        if (annotationsNode != null)
                        {
                            bool previewExists = annotationsNode.Remove("previews");
                            bool columnsDataProfilesExists = annotationsNode.Remove("columnsDataProfiles");
                            bool tableDataProfilesExist = annotationsNode.Remove("tableDataProfiles");

                            if (previewExists || columnsDataProfilesExists || tableDataProfilesExist)
                            {
                                var fullAsset = JObject.Parse(td.Get(asset["id"].ToString()));

                            }
                        }
                                                                  
                        JToken contributor = JObject.Parse("{'role': 'Contributor','members': [{'objectId': '00000000-0000-0000-0000-000000000201'}]}");
                        var roles = new JArray();
                        roles.Add(contributor);

                        foreach (var rolesNode in asset.SelectTokens("$..roles").ToList())
                        {
                            rolesNode.Replace(roles);
                        }
                        //RemoveSystemProperties(asset);

                        //(asset["annotations"] as JObject).Remove("tags");
                        //(asset["annotations"] as JObject).Remove("descriptions");
                        //(asset["annotations"] as JObject).Remove("documentation");
                        (asset["annotations"] as JObject).Remove("termTags");
                        (asset["annotations"] as JObject).Remove("experts");
                        //(asset["annotations"] as JObject).Remove("columnTags");
                        //(asset["annotations"] as JObject).Remove("friendlyName");
                        // We'll need the friendlyName & Descriptions & Tags as well
                        //The above lines not commented out are being referenced as of now, the others can be 'non-commented' if required

                        string WriteToFile(string directory, string name) //Code for naming convention of the files to include the tag and date
                        {
                            string filename = String.Format("{0}_{1}_{2:yyyyMMdd}.{3}", name, searchString.Substring(5), DateTime.Now, "csv");
                            string path = Path.Combine(directory, filename);
                            return path;
                        }

                        //ColumnCsvData
                        string TbleName = (string)asset["properties"]["name"];
                        int col_loop_cnt = 0;
                        do
                        {

                            string columnTags = "";
                            string description = "";
                            string name = (string)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["name"];
                            string typpe = (string)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["type"];
                            int maxLength = (int)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["maxLength"];
                            int precision = (int)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["precision"];
                            bool isNullable = (bool)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["isNullable"];

                            if (asset["annotations"]["columnDescriptions"] != null)
                            {
                                int col_desc_loop_cnt = 0;
                                do
                                {

                                    if ((string)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["name"] == (string)asset["annotations"]["columnDescriptions"][col_desc_loop_cnt]["properties"]["columnName"])
                                    {
                                        
                                        if ((col_desc_loop_cnt >= 1) && (string)asset["annotations"]["columnDescriptions"][col_desc_loop_cnt]["properties"]["columnName"] == (string)asset["annotations"]["columnDescriptions"][col_desc_loop_cnt - 1]["properties"]["columnName"])
                                        {
                                            description = (string)asset["annotations"]["columnDescriptions"][col_desc_loop_cnt - 1]["properties"]["description"] + ";" + (string)asset["annotations"]["columnDescriptions"][col_desc_loop_cnt]["properties"]["description"];

                                        }
                                        else
                                        {
                                            description = (string)asset["annotations"]["columnDescriptions"][col_desc_loop_cnt]["properties"]["description"];
                                        }
                                    }

                                    col_desc_loop_cnt++;
                                } while (col_desc_loop_cnt != col_desc_cnt);
                            }

                            if (asset["annotations"]["columnTags"] != null)
                            {
                                int coltag_loop_cnt = 0;
                                do
                                {
                                    if ((string)asset["annotations"]["schema"]["properties"]["columns"][col_loop_cnt]["name"] == (string)asset["annotations"]["columnTags"][coltag_loop_cnt]["properties"]["columnName"])
                                    {
                                        if ((coltag_loop_cnt >= 1) && (string)asset["annotations"]["columnTags"][coltag_loop_cnt]["properties"]["columnName"] == (string)asset["annotations"]["columnTags"][coltag_loop_cnt - 1]["properties"]["columnName"])
                                        {
                                            columnTags = (string)asset["annotations"]["columnTags"][coltag_loop_cnt - 1]["properties"]["tag"] + ";" + (string)asset["annotations"]["columnTags"][coltag_loop_cnt]["properties"]["tag"];

                                        }
                                        else
                                        {
                                            columnTags = (string)asset["annotations"]["columnTags"][coltag_loop_cnt]["properties"]["tag"];
                                        }
                                    }
                                    coltag_loop_cnt++;
                                } while (coltag_loop_cnt != coltag_cnt);
                            }

                            var col_csv_data = string.Format("{0},{1},{2},{3},{4},{5},{6},{7}", TbleName, name, description, columnTags, typpe, maxLength, precision, isNullable);
                            col_csv.AppendLine(col_csv_data);
                            string colmncsv = WriteToFile(@"C:\Users\Amitech\source\repos\sdc-etl-specialty\ADCImportExport\bin\Debug", "COA_ColumnTable");
                            File.WriteAllText(colmncsv, col_csv.ToString()); //type up some exception handling
                            col_loop_cnt++;
                        } while (col_loop_cnt != col_cnt);


                        //TableCSVData
                        string Namee = (string)asset["properties"]["name"];
                        string FriendlyNamee = "";
                        if (asset["annotations"]["friendlyName"] != null)
                        {
                            FriendlyNamee = (string)asset["annotations"]["friendlyName"]["properties"]["friendlyName"];
                        }
                        string TableDescriptione = "";
                        string TableTagse = "";
                        string nameoflastregisteredbye = (string)asset["properties"]["lastRegisteredBy"]["firstName"] + " " + (string)asset["properties"]["lastRegisteredBy"]["lastName"];
                        string emailoflastregisteredbye = (string)asset["properties"]["lastRegisteredBy"]["upn"];
                        string documentatione = "";
                        if (asset["annotations"]["documentation"] != null)
                        {
                            documentatione = (string)asset["annotations"]["documentation"]["properties"]["content"];
                        }
                        if (asset["annotations"]["descriptions"] != null)
                        {
                            int desc_loop_cnt = 0;
                            do
                            {
                                if (desc_loop_cnt >= 1)
                                {
                                    int neg_desc_loop_cnt = desc_loop_cnt;
                                    do
                                    {
                                        TableDescriptione = TableDescriptione + ";" + (string)asset["annotations"]["descriptions"][neg_desc_loop_cnt]["properties"]["description"];
                                        neg_desc_loop_cnt--;
                                    } while (neg_desc_loop_cnt != 0);
                                }
                                else
                                {
                                    TableDescriptione = (string)asset["annotations"]["descriptions"][desc_loop_cnt]["properties"]["description"];
                                }
                                desc_loop_cnt++;
                            } while (desc_loop_cnt != desc_cnt);
                        }
                        if (asset["annotations"]["tags"] != null)
                        {
                            int tags_loop_cnt = 0;
                            do
                            {
                                if (tags_loop_cnt >= 1)
                                {
                                    int neg_tags_loop_cnt = tags_loop_cnt;
                                    do
                                    {
                                        TableTagse = TableTagse + ";" + (string)asset["annotations"]["tags"][neg_tags_loop_cnt]["properties"]["tag"];
                                        neg_tags_loop_cnt--;
                                    } while (neg_tags_loop_cnt != 0);
                                }
                                else
                                {
                                    TableTagse = (string)asset["annotations"]["tags"][tags_loop_cnt]["properties"]["tag"];
                                }
                                tags_loop_cnt++;
                            } while (tags_loop_cnt != tags_cnt);
                        }
                        var tbl_csv_data = string.Format("{0},{1},{2},{3},{4},{5},{6}", Namee, FriendlyNamee, TableDescriptione, TableTagse, nameoflastregisteredbye, emailoflastregisteredbye, documentatione);
                        tbl_csv.AppendLine(tbl_csv_data);
                        string tblcsv = WriteToFile(@"C:\Users\Amitech\source\repos\sdc-etl-specialty\ADCImportExport\bin\Debug", "COA_TableDetails");
                        File.WriteAllText(tblcsv, tbl_csv.ToString()); //exception handling here as well

                        sw.Write(JsonConvert.SerializeObject(asset));
                        totalExportedSuccessfully++;
                        if (totalExportedSuccessfully % 10 == 0)
                        {
                            Console.Write(".");
                        }
                    }
                       
                    else
                {
                    System.Console.WriteLine("The object type being imported is not type: Table.");                    
                }

            }

                startPage++;            
                
            } while ((startPage - 1) * countPerPage < totalResultsCount);

            sw.Write("]}");

            Console.WriteLine("");                       
            return totalExportedSuccessfully;
        }

        

        /* static void Import(AzureDataCatalog td, string exportedCatalogFilePath)
        {
            int totalAssetsImportSucceeded = 0;
            int totalAssetsImportFailed = 0;

            System.IO.StreamReader sr = new StreamReader(exportedCatalogFilePath);
            JsonTextReader reader = new JsonTextReader(sr);

            StringWriter sw = new StringWriter(new StringBuilder());

            JsonTextWriter jtw = new JsonTextWriter(sw);

            reader.Read();
            if (reader.TokenType != JsonToken.StartObject)
            {
                throw new Exception("Invalid Json. Expected StartObject");
            }

            reader.Read();
            if ((reader.TokenType != JsonToken.PropertyName) || (!reader.Value.ToString().Equals("catalog")))
            {
                throw new Exception("Invalid Json. Expected catalog array");
            }

            reader.Read();
            if (reader.TokenType != JsonToken.StartArray)
            {
                throw new Exception("Invalid Json. Expected StartArray");
            }

            while (reader.Read())
            {
                if (reader.TokenType == JsonToken.EndArray)
                    break;

                jtw.WriteToken(reader);

                JObject asset = JObject.Parse(sw.ToString());

                string id = asset["id"].ToString();
                asset.Remove("id");
                string[] idInfo = id.Split(new char[] { '/' });
                string newid;

                string UpdateResponse = td.Update(asset.ToString(), idInfo[idInfo.Length - 2], out newid);

                if ((UpdateResponse != null) && (!string.IsNullOrEmpty(newid)))
                {
                    totalAssetsImportSucceeded++;

                    if (totalAssetsImportSucceeded % 50 == 0)
                    {
                        System.Console.WriteLine(totalAssetsImportSucceeded + "Assets Imported Succesfully");
                    }
                }
                else
                {
                    totalAssetsImportFailed++;
                }

                //reset local variables for next iteration
                sw = new StringWriter(new StringBuilder());
                jtw = new JsonTextWriter(sw);

            }

            Console.WriteLine("Total Imported Success: " + totalAssetsImportSucceeded);
            Console.WriteLine("Total Imported Failed: " + totalAssetsImportFailed);
        }
        */

         private static void RemoveSystemProperties(JObject payload, bool isRoot = true)
        {
            foreach (var propertyName in ((IDictionary<string, JToken>)payload).Keys.ToArray()
                .Where(k => k != "properties" && k != "annotations" && !(k == "id" && isRoot)))
            {
                payload.Remove(propertyName);
            }

            JToken annotationsJToken;
            if (payload.TryGetValue("annotations", out annotationsJToken) && annotationsJToken.Type == JTokenType.Object)
            {
                var annotationsJObject = (JObject)annotationsJToken;
                foreach (var jProperty in annotationsJObject.Properties())
                {
                    if (jProperty.Value.Type == JTokenType.Object)
                    {
                        var nextPayload = (JObject)jProperty.Value;
                        RemoveSystemProperties(nextPayload, false);
                        annotationsJObject[jProperty.Name] = nextPayload;
                    }
                    else if (jProperty.Value.Type == JTokenType.Array)
                    {
                        foreach (var jItem in ((JArray)jProperty.Value).Where(i => i.Type == JTokenType.Object))
                        {
                            RemoveSystemProperties((JObject)jItem, false);
                        }

                        annotationsJObject[jProperty.Name] = jProperty.Value;
                    }
                }
            }
        } 

        public class AzureDataCatalog
        {
            private readonly string ClientId;
            private readonly Uri RedirectUri;
            private readonly string CatalogName;

            private static AuthenticationResult auth;
            // this is the legacy auth url prior to .NET 4.3 - private static readonly AuthenticationContext AuthContext = new AuthenticationContext("https://login.windows.net/common/oauth2/authorize");
            // this is a legacy auth url, use the one uncommented below for ..../common -- private static readonly AuthenticationContext AuthContext = new AuthenticationContext("https://login.microsoftonline.com/authorize/oauth2/token");
            private static readonly AuthenticationContext AuthContext = new AuthenticationContext("https://login.microsoftonline.com/common");

            public AzureDataCatalog()
            {
                //NOTE: You must fill in the App.Config with the following three settings. The first two are values that you received registered your application with AAD. The 3rd setting is always the same value.:
                //< ADCImportExport.Properties.Settings >
                //    <setting name = "ClientId" serializeAs = "String">
                //           <value></value>
                //       </setting>
                //       <setting name = "RedirectURI" serializeAs = "String">
                //              <value> https://login.live.com/oauth20_desktop.srf</value>
                //    </setting>
                //    <setting name = "ResourceId" serializeAs = "String">
                //           <value> https://datacatalog.azure.com</value>
                //    </setting>
                //</ADCImportExport.Properties.Settings>

                //                ClientId = ADCImportExport.Properties.Settings.Default.ClientId;
                //                ClientId = System.Configuration.ConfigurationSettings.AppSettings.ClientId;
                ClientId = System.Configuration.ConfigurationSettings.AppSettings["ClientId"];

                //RedirectUri = new Uri(ADCImportExport.Properties.Settings.Default.RedirectURI);
                RedirectUri = new Uri(System.Configuration.ConfigurationSettings.AppSettings["RedirectUri"]);
                CatalogName = "DefaultCatalog";

                auth = AuthContext.AcquireTokenAsync("https://api.azuredatacatalog.com", ClientId, RedirectUri, new PlatformParameters(PromptBehavior.Always)).Result;
            }

            public string Get(string uri)
            {

                var fullUri = string.Format("{0}?api-version=2016-03-30", uri);

                string requestId = null;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullUri);
                request.Method = "GET";

                try
                {
                    string s = GetPayload(request, out requestId);
                    return s;
                }
                catch (WebException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.Status);
                    Console.WriteLine("Request Id: " + requestId);

                    if (ex.Response != null)
                    {
                        // can use ex.Response.Status, .StatusDescription
                        if (ex.Response.ContentLength != 0)
                        {
                            using (var stream = ex.Response.GetResponseStream())
                            {
                                using (var reader = new StreamReader(stream))
                                {
                                    Console.WriteLine("Failed Get of asset: " + uri);
                                    Console.WriteLine(reader.ReadToEnd());
                                }
                            }
                        }
                    }
                    return null;
                }
            }

            public string Search(string searchTerm, int startPage, int count)
            {
                var fullUri = string.Format("https://api.azuredatacatalog.com/catalogs/{0}/search/search?searchTerms={1}&count={2}&startPage={3},&api-version=2016-03-30", CatalogName, searchTerm, count, startPage);

                string requestId = null;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullUri);
                request.Method = "GET";

                try
                {
                    string s = GetPayload(request, out requestId);
                    return s;
                }
                catch (WebException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.Status);
                    Console.WriteLine("Request Id: " + requestId);
                    if (ex.Response != null)
                    {
                        // can use ex.Response.Status, .StatusDescription
                        if (ex.Response.ContentLength != 0)
                        {
                            using (var stream = ex.Response.GetResponseStream())
                            {
                                using (var reader = new StreamReader(stream))
                                {
                                    Console.WriteLine(reader.ReadToEnd());
                                }
                            }
                        }
                    }
                    return null;
                }
            }

            public string Update(string postPayload, string viewType, out string id)
            {

                var fullUri = string.Format("https://api.azuredatacatalog.com/catalogs/{0}/views/{1}?api-version=2016-03-30", CatalogName, viewType);

                string requestId = null;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(fullUri);
                request.Method = "POST";
                try
                {
                    var response = SetRequestAndGetResponse(request, out requestId, postPayload);
                    var responseStream = response.GetResponseStream();

                    id = response.Headers["location"];

                    StreamReader reader = new StreamReader(responseStream);
                    return reader.ReadToEnd();
                }
                catch (WebException ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.Status);
                    Console.WriteLine("Request Id: " + requestId);
                    if (ex.Response != null)
                    {
                        // can use ex.Response.Status, .StatusDescription
                        if (ex.Response.ContentLength != 0)
                        {
                            using (var stream = ex.Response.GetResponseStream())
                            {
                                using (var reader = new StreamReader(stream))
                                {
                                    Console.WriteLine("Failed Update of asset: " + postPayload.Substring(0, 50));
                                    Console.WriteLine(reader.ReadToEnd());
                                }
                            }
                        }
                    }
                    id = null;
                    return null;
                }
            }

            private static HttpWebResponse SetRequestAndGetResponse(HttpWebRequest request, out string requestId, string payload = null)
            {
                while (true)
                {
                    //Add a guid to help with diagnostics
                    requestId = Guid.NewGuid().ToString();
                    request.Headers.Add("x-ms-client-request-id", requestId);
                    //To authorize the operation call, you need an access token which is part of the Authorization header
                    request.Headers.Add("Authorization", auth.CreateAuthorizationHeader());
                    //Set to false to be able to intercept redirects
                    request.AllowAutoRedirect = false;

                    if (!string.IsNullOrEmpty(payload))
                    {
                        byte[] byteArray = Encoding.UTF8.GetBytes(payload);
                        request.ContentLength = byteArray.Length;
                        request.ContentType = "application/json";
                        //Write JSON byte[] into a Stream
                        request.GetRequestStream().Write(byteArray, 0, byteArray.Length);
                    }
                    else
                    {
                        request.ContentLength = 0;
                    }

                    HttpWebResponse response = request.GetResponse() as HttpWebResponse;

                    // Requests to **Azure Data Catalog (ADC)** may return an HTTP 302 response to indicate
                    // redirection to a different endpoint. In response to a 302, the caller must re-issue
                    // the request to the URL specified by the Location response header. 
                    if (response.StatusCode == HttpStatusCode.Redirect)
                    {
                        string redirectedUrl = response.Headers["Location"];
                        HttpWebRequest nextRequest = WebRequest.Create(redirectedUrl) as HttpWebRequest;
                        nextRequest.Method = request.Method;
                        request = nextRequest;
                    }
                    else
                    {
                        return response;
                    }
                }
            }

            private static string GetPayload(HttpWebRequest request, out string requestId)
            {
                string result = String.Empty;
                var response = SetRequestAndGetResponse(request, out requestId);
                if (response.StatusCode != HttpStatusCode.OK)
                    throw new ApplicationException("Request wrong");
                var stream = response.GetResponseStream();
                StreamReader reader = new StreamReader(stream);
                result = reader.ReadToEnd();
                return result;
            }
        }
    }
}